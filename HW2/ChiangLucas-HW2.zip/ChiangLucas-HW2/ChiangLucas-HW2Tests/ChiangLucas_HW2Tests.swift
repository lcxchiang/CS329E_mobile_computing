//
//  ChiangLucas_HW2Tests.swift
//  ChiangLucas-HW2Tests
//
//  Created by Lucas Chiang on 9/16/25.
//

import Testing
@testable import ChiangLucas_HW2

struct ChiangLucas_HW2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
