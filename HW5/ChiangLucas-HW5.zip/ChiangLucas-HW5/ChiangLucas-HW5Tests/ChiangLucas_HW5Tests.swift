//
//  ChiangLucas_HW5Tests.swift
//  ChiangLucas-HW5Tests
//
//  Created by Lucas Chiang on 10/13/25.
//

// Project: ChiangLucas-HW5
// EID: lmc4866
// Course: CS329E

import Testing
@testable import ChiangLucas_HW5

struct ChiangLucas_HW5Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
