//
//  AddPizza.swift
//  ChiangLucas-HW5
//
//  Created by Lucas Chiang on 10/15/25.
//

// Project: ChiangLucas-HW5
// EID: lmc4866
// Course: CS329E

protocol AddPizza {
    func addPizza (Pizza: Pizza)
}
