// Project: ChiangLucas-HW3
// EID: lmc4866
// Course: CS329E

import Testing
@testable import ChiangLucas_HW3

struct ChiangLucas_HW3Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
