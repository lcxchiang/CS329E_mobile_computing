// Project: ChiangLucas-HW3
// EID: lmc4866
// Course: CS329E

protocol TextChanger {
    func changeText(newName:String)
    func changeTextColor(newColor:String)
}
