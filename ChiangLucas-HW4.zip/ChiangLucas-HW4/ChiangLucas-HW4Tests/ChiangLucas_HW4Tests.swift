//
//  ChiangLucas_HW4Tests.swift
//  ChiangLucas-HW4Tests
//
//  Created by Lucas Chiang on 10/5/25.
//

// Project: ChiangLucas-HW4
// EID: lmc4866
// Course: CS329E

import Testing
@testable import ChiangLucas_HW4

struct ChiangLucas_HW4Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
