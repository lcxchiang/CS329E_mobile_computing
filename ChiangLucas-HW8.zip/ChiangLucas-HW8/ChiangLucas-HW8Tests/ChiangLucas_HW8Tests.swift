//
//  ChiangLucas_HW8Tests.swift
//  ChiangLucas-HW8Tests
//
//  Created by Lucas Chiang on 11/10/25.
//

// Project: LastnameFirstname-HW8
// EID: lmc4866
// Course: CS329E

import Testing
@testable import ChiangLucas_HW8

struct ChiangLucas_HW8Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
