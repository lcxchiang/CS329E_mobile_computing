//
//  ChiangLucas_HW8UITestsLaunchTests.swift
//  ChiangLucas-HW8UITests
//
//  Created by Lucas Chiang on 11/10/25.
//

// Project: LastnameFirstname-HW8
// EID: lmc4866
// Course: CS329E

import XCTest

final class ChiangLucas_HW8UITestsLaunchTests: XCTestCase {

    override class var runsForEachTargetApplicationUIConfiguration: Bool {
        true
    }

    override func setUpWithError() throws {
        continueAfterFailure = false
    }

    @MainActor
    func testLaunch() throws {
        let app = XCUIApplication()
        app.launch()

        // Insert steps here to perform after app launch but before taking a screenshot,
        // such as logging into a test account or navigating somewhere in the app

        let attachment = XCTAttachment(screenshot: app.screenshot())
        attachment.name = "Launch Screen"
        attachment.lifetime = .keepAlways
        add(attachment)
    }
}
